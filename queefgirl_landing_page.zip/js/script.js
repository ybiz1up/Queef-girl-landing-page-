document.addEventListener("DOMContentLoaded", () => {
    gsap.from("#main-title", { duration: 1.5, opacity: 0, y: -50 });
});
